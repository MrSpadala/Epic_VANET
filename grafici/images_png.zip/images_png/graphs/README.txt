We have considered as outliers the simulations where the message received less than 5% of all the cars. 
